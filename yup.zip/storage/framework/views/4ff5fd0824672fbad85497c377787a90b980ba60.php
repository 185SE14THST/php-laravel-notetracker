<?php $__env->startSection('content'); ?>
    <?php if( auth()->check() ): ?>
    <div class="container">


        <h3>My Notes </h3>
        <div>
            <table class="table table-hover table-sm">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Date</th>
                    <th scope="col">Title</th>
                    <th scope="col">Preview</th>
                    <th scope="col">Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $t = 1 ?>
                <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($t++); ?></th>
                        <td><?php echo e($n->updated_at->diffForHumans()); ?></td>
                        <td><?php echo e($n->title); ?> </td>
                        <td data-toggle="tooltip" data-placement="top" title="<?php echo e($n->note); ?>">
                            <?php echo e(substr($n->note, 0, 55)); ?>...
                        </td>
                        <td>
                            <a href="note/<?php echo e($n->id); ?>" data-toggle="tooltip" data-placement="top" title="Edit this note"><span><i class="fa fa-address-book-o" aria-hidden="true"></i></span></a>
                            <a href="delete/<?php echo e($n->id); ?>" data-toggle="tooltip" data-placement="top" title="Delete this note"><span><i class="fa fa-trash" aria-hidden="true"></i></span></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
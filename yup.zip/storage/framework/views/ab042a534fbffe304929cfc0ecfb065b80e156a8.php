<?php if(Session::has('success')): ?>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true"><strong><?php echo session('success'); ?>&times;</strong></span>
    </button>
<?php endif; ?>
<?php if(Session::has('warning')): ?>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true"><strong><?php echo session('warning'); ?>&times;</strong></span>
    </button>
<?php endif; ?>
<?php if(Session::has('info')): ?>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true"><strong><?php echo session('info'); ?>&times;</strong></span>
    </button>
<?php endif; ?>
<?php if(Session::has('danger')): ?>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true"><strong><?php echo session('danger'); ?>&times;</strong></span>
    </button>
<?php endif; ?>